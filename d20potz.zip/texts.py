TEXT_HELP = "Help"
TEXT_ROLL = "Roll"